import { supabase } from "./supabaseClient";

export type ChatMessage = {
  id: string;
  session_id: string;
  name: string;
  email: string;
  message: string;
  sender: "visitor" | "admin";
  status: "new" | "read";
  created_at: string;
};

type ChatMode = "visitor" | "admin";

const SESSION_KEY = "quartz_chat_session";

const canUseStorage = () => typeof window !== "undefined" && typeof window.localStorage !== "undefined";

export const getChatSessionId = () => {
  if (!canUseStorage()) return "";
  const existing = localStorage.getItem(SESSION_KEY);
  if (existing) return existing;
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  localStorage.setItem(SESSION_KEY, id);
  return id;
};

export const fetchChatMessages = async (mode: ChatMode, sessionId?: string) => {
  let query = supabase
    .from("chat_messages")
    .select("id, session_id, name, email, message, sender, status, created_at")
    .order("created_at", { ascending: true });

  if (mode === "visitor" && sessionId) {
    query = query.eq("session_id", sessionId);
  }

  const { data, error } = await query;
  if (error) {
    console.error(error);
    return [] as ChatMessage[];
  }
  return (data ?? []) as ChatMessage[];
};

export const subscribeToChatMessages = (mode: ChatMode, onChange: () => void, sessionId?: string) => {
  const payload: { event: string; schema: string; table: string; filter?: string } = {
    event: "*",
    schema: "public",
    table: "chat_messages",
  };

  if (mode === "visitor" && sessionId) {
    payload.filter = `session_id=eq.${sessionId}`;
  }

  const channel = supabase
    .channel("chat_messages")
    .on("postgres_changes", payload, () => onChange())
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};

export const sendChatMessage = async (args: {
  sessionId: string;
  name: string;
  email: string;
  message: string;
  sender: "visitor" | "admin";
}) => {
  const { sessionId, name, email, message, sender } = args;
  const payload = {
    session_id: sessionId,
    name,
    email,
    message,
    sender,
    status: sender === "visitor" ? "new" : "read",
  };

  const { error } = await supabase.from("chat_messages").insert(payload);
  if (error) {
    console.error(error);
    return false;
  }
  return true;
};

export const markVisitorMessagesRead = async (sessionId?: string) => {
  let query = supabase.from("chat_messages").update({ status: "read" }).eq("sender", "visitor");
  if (sessionId) {
    query = query.eq("session_id", sessionId);
  }
  const { error } = await query;
  if (error) {
    console.error(error);
  }
};
